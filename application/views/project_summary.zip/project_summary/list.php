<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-tasks" aria-hidden="true"></i> Project Summary Management
        <small>Add, Edit, Delete</small>
      </h1>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-12 text-right">
                <div class="form-group">
                    <a class="btn btn-primary" href="<?php echo base_url(); ?>projectSummary/add"><i class="fa fa-plus"></i> Add New Project</a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Project Summary List</h3>
                    <div class="box-tools">
                        <form action="<?php echo base_url() ?>projectSummary/projectListing" method="POST" id="searchList">
                            <div class="input-group">
                              <input type="text" name="searchText" value="<?php echo $searchText; ?>" class="form-control input-sm pull-right" style="width: 150px;" placeholder="Search"/>
                              <div class="input-group-btn">
                                <button class="btn btn-sm btn-default searchList"><i class="fa fa-search"></i></button>
                              </div>
                            </div>
                        </form>
                    </div>
                </div><!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
                  <table class="table table-hover">
                    <tr>
                        <th>Sr No</th>
                        <th>Work Name</th>
                        <th>District</th>
                        <th>Block</th>
                        <th>Department</th>
                        <th>Project Cost</th>
                        <th>Proposal Estimate</th>
                        <th>Status</th>
                        <th>Officer Name</th>
                        <th>Contact No</th>
                        <th>Created Date</th>
                        <th class="text-center">Actions</th>
                    </tr>
                    <?php
                    if(!empty($records))
                    {
                        $sno = 1;
                        foreach($records as $record)
                        {
                    ?>
                    <tr>
                        <td><?php echo $sno ?></td>
                        <td><?php echo $record->work_name ?></td>
                        <td><?php echo $record->district_name ?></td>
                        <td><?php echo $record->block_name ?></td>
                        <td><?php echo $record->department_name ?></td>
                        <td>₹<?php echo number_format($record->amount_project_cost, 2) ?></td>
                        <td>₹<?php echo number_format($record->proposal_estimate, 2) ?></td>
                        <td>
                            <span class="label <?php echo ($record->status == 'Completed') ? 'label-success' : (($record->status == 'In Progress') ? 'label-warning' : 'label-info') ?>">
                                <?php echo $record->status ?>
                            </span>
                        </td>
                        <td><?php echo $record->officer_name ?></td>
                        <td><?php echo $record->contact_no ?></td>
                        <td><?php echo date("d-m-Y", strtotime($record->created_at)) ?></td>
                        <td class="text-center">
                          
                            <a class="btn btn-sm btn-info" href="<?php echo base_url().'projectSummary/edit/'.$record->id; ?>" title="Edit"><i class="fa fa-pencil"></i></a>
                          
                         
                            <a class="btn btn-sm btn-danger deleteProject" href="#" data-projectid="<?php echo $record->id; ?>" title="Delete"><i class="fa fa-trash"></i></a>
                           
                        </td>
                    </tr>
                    <?php
                        $sno++;
                        }
                    }
                    else
                    {
                        echo '<tr><td colspan="12" class="text-center">No records found</td></tr>';
                    }
                    ?>
                  </table>
                  
                </div><!-- /.box-body -->
                <div class="box-footer clearfix">
                    <?php echo $this->pagination->create_links(); ?>
                </div>
              </div><!-- /.box -->
            </div>
        </div>
    </section>
</div>

<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script type="text/javascript">
    jQuery(document).ready(function(){
        jQuery('ul.pagination li a').click(function (e) {
            e.preventDefault();            
            var link = jQuery(this).get(0).href;            
            var value = link.substring(link.lastIndexOf('/') + 1);
            jQuery("#searchList").attr("action", baseURL + "projectSummary/projectListing/" + value);
            jQuery("#searchList").submit();
        });
    });
</script>

<script>
    jQuery(document).ready(function(){
        jQuery(document).on("click", ".deleteProject", function(){
            var projectId = $(this).data("projectid"),
                hitURL = baseURL + "projectSummary/delete",
                currentRow = $(this);
            
            var confirmation = confirm("Are you sure to delete this project ?");
            
            if(confirmation)
            {
                jQuery.ajax({
                type : "POST",
                dataType : "json",
                url : hitURL,
                data : { projectId : projectId } 
                }).done(function(data){
                    console.log(data);
                    currentRow.parents('tr').remove();
                    if(data.status = true) { alert("Project successfully deleted"); }
                    else if(data.status = false) { alert("Project deletion failed"); }
                    else { alert("Access denied..!"); }
                });
            }
        });
    });
</script>
